<?php

/**
 * Admin class (extends user with no other property or method)
 */
class Wol_Admin extends Wol_User {}
?>
