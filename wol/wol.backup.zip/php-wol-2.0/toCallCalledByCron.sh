#!/bin/bash

php ./calledByCron.php `date +"%k %M %u %m %d"`
